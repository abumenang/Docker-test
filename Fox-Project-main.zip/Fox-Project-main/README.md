The python exercise comprises of two files: the 'script' and 'Python-Answer' files.
For terraform ressources will need to be provisioned in a public subnet and a security group with 'ssh' and 'https' port open has to be attached to the instance.
The key pair created will output its public key which has to be saved for ssh connection.
